
import java.rmi.*;

public interface IChatServer extends Remote {

    public void send(String msg) throws RemoteException;
    public void addClient(IChatClient client) throws RemoteException;

}
