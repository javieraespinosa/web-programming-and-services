
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

public class ChatClient extends UnicastRemoteObject implements IChatClient {

    IChatServer server;

    public ChatClient() throws RemoteException {
        // Constructor
    }

    public void connectTo(IChatServer server) throws RemoteException {
        this.server = server;
        server.addClient(this);
    }

    @Override
    public void notify(String msg) throws RemoteException {
        System.out.println(msg);
    }

} // class

