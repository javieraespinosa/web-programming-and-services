
import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class Run {

    public static void main(String[] args) {

        init();

        if(args[0].compareTo("server") == 0)
            runServer();

        if(args[0].compareTo("client") == 0)
            runClient();

    } // method


    public static void runServer(){

        try {

            int PORT = 1099; // default port
            LocateRegistry.createRegistry(PORT); // start rmiregistry

            ChatServer server = new ChatServer();
            Naming.rebind("rmi://localhost/ChatServer", server);

            System.out.println("Chat server running...");

        } catch (Exception e) { System.out.println("Chat server failed: " + e); }

    } // method


    public static void runClient(){


        try {

            IChatServer server = (IChatServer)Naming.lookup("rmi://localhost/ChatServer");

            ChatClient client = new ChatClient();
            client.connectTo(server);

            System.out.println("Connected!");

        } catch (Exception e) { System.out.println("Chat Client problem: " + e); }

    } // method


    public static void init() {

        if (System.getSecurityManager() == null)
            System.setSecurityManager(new SecurityManager());

    } // method

} // class
