#!/bin/bash
java -Djava.security.policy=file:security.policy Run client