
import java.rmi.*;

public interface IChatClient extends Remote {

    public void notify(String msg) throws RemoteException;

}
