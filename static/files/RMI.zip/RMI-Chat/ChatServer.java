
import java.rmi.*;
import java.rmi.server.*;
import java.util.ArrayList;

public class ChatServer extends UnicastRemoteObject implements IChatServer {

    private ArrayList<IChatClient> clients;

    public ChatServer() throws RemoteException {
        clients = new ArrayList<IChatClient>();
    }

    @Override
    public void send(String msg) throws RemoteException {
        for(int i=0; i<clients.size(); i++)
            clients.get(i).notify(msg);
    }

    @Override
    public void addClient(IChatClient client) throws RemoteException {
        clients.add(client);
        this.send("user connected");
    }

} // class
