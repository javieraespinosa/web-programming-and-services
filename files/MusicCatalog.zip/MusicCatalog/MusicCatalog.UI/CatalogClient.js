
var CatalogClient = function () {

    var ALBUMS_URI = 'http://localhost:3000/albums';
    var ALBUM_URI  = 'http://localhost:3000/albums/{_}';

    this.addAlbum = function (album, callback) {
        var url  = ALBUM_URI.replace('{_}', album.id);
        var data = JSON.stringify(album);
        this.doRequest('PUT', url, data);
    }; // method

    this.getAlbum = function (albumID, callback) {
        var url = ALBUM_URI.replace('{_}', albumID);
        var album = this.doRequest('GET', url, null);
        console.log(album);
    }; // method

    this.removeAlbum = function (albumID, callback) {
        var url = ALBUM_URI.replace('{_}', albumID);
        this.doRequest('DELETE', url, null);
    }; // method

    this.getAlbums = function (callback) {
        var albums = this.doRequest('GET', ALBUMS_URI, null);
        for(var albumID in albums) {
            console.log(albums[albumID]);
        }
    }; // method

    this.doRequest = function(verb, url, data) {

        var response;

        $.ajax({
            url:  url,
            type: verb,
            async: false,
            success: function(resp) {
                response = resp;
            },
            error: function(xhr) {
                console.log("Error");
            }
        });

        return response;

    }; // method

}; // class
