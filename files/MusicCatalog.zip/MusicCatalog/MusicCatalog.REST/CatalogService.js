
var express    = require('express');
var bodyParser = require('body-parser');
var cors       = require('cors');

var app = express();
app.use(bodyParser.json());
app.use( cors() );

var albums = {};
albums['1'] = { "id":1, "name": 'The 2nd Law', "artist": 'Muse', "year": 2012 };

app.get('/albums', function (request, response) {
    response.json(albums);
});

app.get('/albums/:id', function (request, response) {
    response.json(albums[request.params.id]);
});

app.put('/albums/:id', function (request, response) {
    var album = request.body;
    albums[request.params.id] = album;
    response.json('OK');
});

app.delete('/albums/:id', function (request, response) {
    var deleted = delete albums[request.params.id];
    response.json(deleted);
});

var server = app.listen(3000, function () {
    console.log('Listening at http://localhost:%s', server.address().port);
});





