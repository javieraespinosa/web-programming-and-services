

var CatalogClient = require('./CatalogClient');
var Sequence   = require('sequence').Sequence;

var client = new CatalogClient();

Sequence.create()

    /// Step 0: Show the albums in the catalog
    .then(function (next) {
        client.getAlbums(function (albums) {
            console.log('\n'+'ALBUMS (before insertion)');
            console.log(albums);
            next();
        });
    })

    /// Step 1: Insert new album in Catalog
    .then(function (next) {
        var album = { "id": 2, "name": 'The Resistance', "artist": 'Muse', "year": 2009 };
        client.addAlbum(album, function (resp) {
            next();
        });
    })

    /// Step 2: Insert another album (with errors)
    .then(function (next) {
        var album = { "id": 3, "name": 'XXXX', "artist": 'YYYY', "year": 0000 };
        client.addAlbum(album, function (resp) {
            next();
        });
    })

    /// Step 3: Show the albums in the catalog
    .then(function (next) {
        client.getAlbums(function (albums) {
            console.log('\n'+'ALBUMS (after insertions)');
            console.log(albums);
            next();
        });
    })

    /// Step 4: Remove the album with errors
    .then(function (next) {
        client.removeAlbum('3', function () {
           next();
        });
    })

    /// Step 5: Show (again) the albums in the catalog
    .then(function (next) {
        client.getAlbums(function (albums) {
            console.log('\n'+'ALBUMS (after deletion)');
            console.log(albums);
            next();
        });
    })
;

